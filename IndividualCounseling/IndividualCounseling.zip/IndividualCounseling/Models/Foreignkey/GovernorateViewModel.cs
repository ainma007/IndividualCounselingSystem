﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndividualCounseling.Models.Foreignkey
{
    public class GovernorateViewModel
    {

        public int GovernorateID { get; set; }

        public string GovernorateName { get; set; }

    }
}