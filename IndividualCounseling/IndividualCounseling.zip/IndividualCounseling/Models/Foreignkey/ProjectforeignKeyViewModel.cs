﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndividualCounseling.Models.Foreignkey
{
    public class ProjectforeignKeyViewModel
    {
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
    }
}